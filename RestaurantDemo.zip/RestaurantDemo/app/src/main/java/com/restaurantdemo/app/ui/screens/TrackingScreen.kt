package com.restaurantdemo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.restaurantdemo.app.data.AppRepository
import com.restaurantdemo.app.data.OrderStatus
import com.restaurantdemo.app.ui.components.EmptyState
import com.restaurantdemo.app.ui.theme.MaroonPrimary
import com.restaurantdemo.app.ui.theme.MutedText
import com.restaurantdemo.app.ui.theme.SuccessGreen
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackingScreen(orderId: String, onBack: () -> Unit) {
    val orders by AppRepository.orders.collectAsState()
    val order = orders.find { it.id == orderId }

    // Demo touch: automatically progress the order status over time so the
    // tracking screen feels alive, like a real delivery app. In production
    // this would instead observe live status pushed from the backend.
    LaunchedEffect(orderId) {
        val sequence = OrderStatus.values()
        while (true) {
            delay(6000)
            val current = AppRepository.getOrder(orderId) ?: break
            val currentIndex = sequence.indexOf(current.status)
            if (currentIndex < sequence.lastIndex) {
                AppRepository.updateOrderStatus(orderId, sequence[currentIndex + 1])
            } else break
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Track Order") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        if (order == null) {
            Box(Modifier.padding(padding).fillMaxSize()) {
                EmptyState("😕", "Order not found", "We couldn't find this order.")
            }
            return@Scaffold
        }

        Column(Modifier.padding(padding).fillMaxSize().padding(24.dp)) {
            Text("Order #${order.id}", style = MaterialTheme.typography.titleLarge)
            Text("Placed on ${order.placedAt()}", color = MutedText, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(28.dp))

            val steps = OrderStatus.values()
            val currentIndex = steps.indexOf(order.status)

            steps.forEachIndexed { index, status ->
                TrackingStep(
                    label = status.label,
                    done = index <= currentIndex,
                    isLast = index == steps.lastIndex,
                    isCurrent = index == currentIndex
                )
            }
        }
    }
}

@Composable
private fun TrackingStep(label: String, done: Boolean, isLast: Boolean, isCurrent: Boolean) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (done) SuccessGreen else Color(0xFFE5DED4)),
                contentAlignment = Alignment.Center
            ) {
                if (done) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(40.dp)
                        .background(if (done) SuccessGreen else Color(0xFFE5DED4))
                )
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.padding(bottom = if (isLast) 0.dp else 24.dp)) {
            Text(
                label,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                color = if (done) MaterialTheme.colorScheme.onBackground else MutedText
            )
            if (isCurrent) {
                Text("In progress", color = MaroonPrimary, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
