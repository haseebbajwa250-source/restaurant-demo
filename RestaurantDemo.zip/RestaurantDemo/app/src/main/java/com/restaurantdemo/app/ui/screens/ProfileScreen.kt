package com.restaurantdemo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.restaurantdemo.app.data.AppRepository
import com.restaurantdemo.app.data.Order
import com.restaurantdemo.app.ui.components.SectionHeader
import com.restaurantdemo.app.ui.components.formatPkr
import com.restaurantdemo.app.ui.theme.GoldAccentLight
import com.restaurantdemo.app.ui.theme.MaroonPrimary
import com.restaurantdemo.app.ui.theme.MutedText

@Composable
fun ProfileScreen(
    onOrderClick: (String) -> Unit,
    onOpenAdmin: () -> Unit
) {
    val customer by AppRepository.lastCustomer.collectAsState()
    val orders by AppRepository.orders.collectAsState()
    val addresses by AppRepository.savedAddresses.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaroonPrimary)
                .padding(24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Person, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(customer?.name ?: "Guest Customer", color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Text(customer?.phone ?: "No orders placed yet", color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        SectionHeader("Previous Orders")
        if (orders.isEmpty()) {
            Text(
                "No orders yet. Your order history will appear here.",
                color = MutedText,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )
        } else {
            orders.reversed().forEach { order -> OrderHistoryRow(order) { onOrderClick(order.id) } }
        }

        Spacer(Modifier.height(12.dp))
        SectionHeader("Saved Addresses")
        if (addresses.isEmpty()) {
            Text(
                "No saved addresses yet.",
                color = MutedText,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )
        } else {
            addresses.forEach { addr ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = MaroonPrimary)
                    Spacer(Modifier.width(10.dp))
                    Text(addr, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .clickable { onOpenAdmin() },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = GoldAccentLight)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = MaroonPrimary)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Restaurant Admin Panel", fontWeight = FontWeight.Bold)
                    Text("Manage menu, orders & categories", style = MaterialTheme.typography.bodySmall, color = MutedText)
                }
            }
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun OrderHistoryRow(order: Order, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("Order #${order.id}", fontWeight = FontWeight.Bold)
            Text(order.placedAt(), style = MaterialTheme.typography.bodySmall, color = MutedText)
            Text(order.status.label, style = MaterialTheme.typography.bodySmall, color = MaroonPrimary)
        }
        Text(formatPkr(order.total), fontWeight = FontWeight.Bold)
    }
}
