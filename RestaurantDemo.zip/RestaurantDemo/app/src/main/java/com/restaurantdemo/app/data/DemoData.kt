package com.restaurantdemo.app.data

object DemoData {

    val categories = listOf(
        Category("cat_burgers", "Burgers", "🍔"),
        Category("cat_pizza", "Pizza", "🍕"),
        Category("cat_chicken", "Chicken", "🍗"),
        Category("cat_fastfood", "Fast Food", "🌯"),
        Category("cat_drinks", "Drinks", "🥤"),
        Category("cat_desserts", "Desserts", "🍰"),
    )

    private val addOnsBurger = listOf(
        AddOn("add_cheese", "Extra Cheese", 60),
        AddOn("add_patty", "Extra Patty", 150),
        AddOn("add_mayo", "Extra Mayo", 30),
    )
    private val addOnsPizza = listOf(
        AddOn("add_cheeseburst", "Cheese Burst Crust", 200),
        AddOn("add_olives", "Extra Olives", 80),
        AddOn("add_jalapeno", "Extra Jalapeños", 60),
    )
    private val addOnsRice = listOf(
        AddOn("add_raita", "Raita", 50),
        AddOn("add_salad", "Salad", 40),
    )

    val foodItems = listOf(
        FoodItem(
            id = "food_zinger",
            name = "Zinger Burger",
            description = "Crispy fried chicken fillet, fresh lettuce and creamy mayo in a soft sesame bun.",
            price = 450,
            imageUrl = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&q=80",
            categoryId = "cat_burgers",
            isFeatured = true,
            isPopular = true,
            addOns = addOnsBurger
        ),
        FoodItem(
            id = "food_beefburger",
            name = "Beef Steak Burger",
            description = "Juicy grilled beef patty topped with cheddar cheese, onions and our signature sauce.",
            price = 500,
            imageUrl = "https://images.unsplash.com/photo-1550547660-d9450f859349?w=600&q=80",
            categoryId = "cat_burgers",
            addOns = addOnsBurger
        ),
        FoodItem(
            id = "food_chickenpizza",
            name = "Chicken Pizza",
            description = "Loaded with tender chicken chunks, capsicum and mozzarella cheese on a hand-tossed base.",
            price = 850,
            imageUrl = "https://images.unsplash.com/photo-1601924582970-9238bcb495d9?w=600&q=80",
            categoryId = "cat_pizza",
            isFeatured = true,
            isPopular = true,
            addOns = addOnsPizza
        ),
        FoodItem(
            id = "food_fajitapizza",
            name = "Chicken Fajita Pizza",
            description = "Spicy fajita chicken, bell peppers and onions with extra mozzarella.",
            price = 950,
            imageUrl = "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&q=80",
            categoryId = "cat_pizza",
            isFeatured = true,
            addOns = addOnsPizza
        ),
        FoodItem(
            id = "food_biryani",
            name = "Chicken Biryani",
            description = "Fragrant basmati rice cooked with tender chicken and traditional Pakistani spices.",
            price = 350,
            imageUrl = "https://images.unsplash.com/photo-1631515243349-e0cb75fb8d3a?w=600&q=80",
            categoryId = "cat_chicken",
            isPopular = true,
            addOns = addOnsRice
        ),
        FoodItem(
            id = "food_friedchicken",
            name = "Fried Chicken (4 pcs)",
            description = "Crispy golden fried chicken pieces marinated in our special spice blend.",
            price = 700,
            imageUrl = "https://images.unsplash.com/photo-1562967914-608f82629710?w=600&q=80",
            categoryId = "cat_chicken",
            isPopular = true
        ),
        FoodItem(
            id = "food_loadedfries",
            name = "Loaded Fries",
            description = "Crispy fries topped with cheese sauce, jalapeños and grilled chicken bits.",
            price = 400,
            imageUrl = "https://images.unsplash.com/photo-1585109649139-366815a0d713?w=600&q=80",
            categoryId = "cat_fastfood",
            isFeatured = true
        ),
        FoodItem(
            id = "food_chickenroll",
            name = "Chicken Roll",
            description = "Grilled chicken strips wrapped in soft paratha with mint chutney and salad.",
            price = 300,
            imageUrl = "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=600&q=80",
            categoryId = "cat_fastfood",
            isPopular = true
        ),
        FoodItem(
            id = "food_shawarma",
            name = "Chicken Shawarma",
            description = "Classic shawarma with garlic sauce, pickles and crisp vegetables.",
            price = 320,
            imageUrl = "https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=600&q=80",
            categoryId = "cat_fastfood"
        ),
        FoodItem(
            id = "food_softdrink",
            name = "Soft Drink (500ml)",
            description = "Chilled and refreshing, choice of Coke, Pepsi, Sprite or Fanta.",
            price = 120,
            imageUrl = "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=600&q=80",
            categoryId = "cat_drinks",
            isPopular = true
        ),
        FoodItem(
            id = "food_mintmargarita",
            name = "Mint Margarita",
            description = "A refreshing house-made mint and lime cooler.",
            price = 200,
            imageUrl = "https://images.unsplash.com/photo-1546171753-97d7676e4602?w=600&q=80",
            categoryId = "cat_drinks"
        ),
        FoodItem(
            id = "food_brownie",
            name = "Chocolate Brownie",
            description = "Rich, fudgy chocolate brownie served warm, a perfect way to end your meal.",
            price = 250,
            imageUrl = "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600&q=80",
            categoryId = "cat_desserts",
            isFeatured = true,
            isPopular = true
        ),
        FoodItem(
            id = "food_icecream",
            name = "Ice Cream Sundae",
            description = "Vanilla ice cream drizzled with chocolate sauce and crushed nuts.",
            price = 280,
            imageUrl = "https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?w=600&q=80",
            categoryId = "cat_desserts"
        ),
    )
}
