package com.restaurantdemo.app.nav

object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val MENU = "menu?categoryId={categoryId}"
    fun menu(categoryId: String? = null) = "menu?categoryId=${categoryId ?: ""}"
    const val PRODUCT_DETAIL = "product/{foodId}"
    fun productDetail(foodId: String) = "product/$foodId"
    const val CART = "cart"
    const val CHECKOUT = "checkout"
    const val CONFIRMATION = "confirmation/{orderId}"
    fun confirmation(orderId: String) = "confirmation/$orderId"
    const val TRACKING = "tracking/{orderId}"
    fun tracking(orderId: String) = "tracking/$orderId"
    const val PROFILE = "profile"

    const val ADMIN_HOME = "admin"
    const val ADMIN_PRODUCTS = "admin/products"
    const val ADMIN_PRODUCT_EDIT = "admin/products/edit/{foodId}"
    fun adminProductEdit(foodId: String) = "admin/products/edit/$foodId"
    const val ADMIN_PRODUCT_NEW = "admin/products/new"
    const val ADMIN_CATEGORIES = "admin/categories"
    const val ADMIN_ORDERS = "admin/orders"
}
