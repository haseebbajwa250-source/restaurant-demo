package com.restaurantdemo.app.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

/**
 * Single source of truth for the whole app (customer screens + admin panel).
 *
 * This is an in-memory demo implementation backed by StateFlow, so that:
 *  - Admin changes (price, availability, new items, order status) are
 *    reflected instantly everywhere via Compose state collection.
 *  - Swapping this for Firebase / Room later only means changing the
 *    inside of these functions (fetch from Firestore / Room instead of
 *    mutating in-memory lists) - the public API shape is designed to stay
 *    the same, so screens would not need to change.
 */
object AppRepository {

    const val DELIVERY_FEE = 150

    // ---------- Categories ----------
    private val _categories = MutableStateFlow(DemoData.categories)
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()

    fun addCategory(category: Category) {
        _categories.update { it + category }
    }

    fun deleteCategory(id: String) {
        _categories.update { list -> list.filter { it.id != id } }
    }

    // ---------- Food items ----------
    private val _foodItems = MutableStateFlow(DemoData.foodItems)
    val foodItems: StateFlow<List<FoodItem>> = _foodItems.asStateFlow()

    fun upsertFoodItem(item: FoodItem) {
        _foodItems.update { list ->
            if (list.any { it.id == item.id }) {
                list.map { if (it.id == item.id) item else it }
            } else {
                list + item
            }
        }
    }

    fun deleteFoodItem(id: String) {
        _foodItems.update { list -> list.filter { it.id != id } }
    }

    fun toggleAvailability(id: String) {
        _foodItems.update { list ->
            list.map { if (it.id == id) it.copy(available = !it.available) else it }
        }
    }

    fun newFoodId(): String = "food_${UUID.randomUUID().toString().take(8)}"

    // ---------- Cart ----------
    private val _cart = MutableStateFlow<List<CartLine>>(emptyList())
    val cart: StateFlow<List<CartLine>> = _cart.asStateFlow()

    private fun lineKey(foodId: String, addOns: List<AddOn>) =
        foodId + "|" + addOns.map { it.id }.sorted().joinToString(",")

    fun addToCart(food: FoodItem, quantity: Int, addOns: List<AddOn> = emptyList()) {
        _cart.update { lines ->
            val key = lineKey(food.id, addOns)
            val existing = lines.find { lineKey(it.food.id, it.selectedAddOns) == key }
            if (existing != null) {
                lines.map {
                    if (lineKey(it.food.id, it.selectedAddOns) == key)
                        it.copy(quantity = it.quantity + quantity) else it
                }
            } else {
                lines + CartLine(food, quantity, addOns)
            }
        }
    }

    fun updateQuantity(food: FoodItem, addOns: List<AddOn>, newQuantity: Int) {
        val key = lineKey(food.id, addOns)
        _cart.update { lines ->
            if (newQuantity <= 0) {
                lines.filterNot { lineKey(it.food.id, it.selectedAddOns) == key }
            } else {
                lines.map {
                    if (lineKey(it.food.id, it.selectedAddOns) == key)
                        it.copy(quantity = newQuantity) else it
                }
            }
        }
    }

    fun removeFromCart(food: FoodItem, addOns: List<AddOn>) {
        val key = lineKey(food.id, addOns)
        _cart.update { lines -> lines.filterNot { lineKey(it.food.id, it.selectedAddOns) == key } }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun cartSubtotal(): Int = _cart.value.sumOf { it.lineTotal }
    fun cartCount(): Int = _cart.value.sumOf { it.quantity }

    // ---------- Orders ----------
    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    // ---------- Customer / saved addresses (demo profile) ----------
    private val _lastCustomer = MutableStateFlow<CustomerInfo?>(null)
    val lastCustomer: StateFlow<CustomerInfo?> = _lastCustomer.asStateFlow()

    private val _savedAddresses = MutableStateFlow<List<String>>(emptyList())
    val savedAddresses: StateFlow<List<String>> = _savedAddresses.asStateFlow()

    fun placeOrder(customer: CustomerInfo, paymentMethod: PaymentMethod): Order {
        val subtotal = cartSubtotal()
        val fee = if (subtotal > 0) DELIVERY_FEE else 0
        val order = Order(
            id = "RD-" + (1000 + _orders.value.size + 1),
            items = _cart.value,
            customer = customer,
            paymentMethod = paymentMethod,
            subtotal = subtotal,
            deliveryFee = fee,
            total = subtotal + fee,
            status = OrderStatus.RECEIVED
        )
        _orders.update { it + order }
        _lastCustomer.value = customer
        if (customer.address.isNotBlank() && !_savedAddresses.value.contains(customer.address)) {
            _savedAddresses.update { it + customer.address }
        }
        clearCart()
        return order
    }

    fun updateOrderStatus(orderId: String, status: OrderStatus) {
        _orders.update { list -> list.map { if (it.id == orderId) it.copy(status = status) else it } }
    }

    fun getOrder(orderId: String): Order? = _orders.value.find { it.id == orderId }
}
