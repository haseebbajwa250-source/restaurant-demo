package com.restaurantdemo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.restaurantdemo.app.data.AppRepository
import com.restaurantdemo.app.ui.components.formatPkr
import com.restaurantdemo.app.ui.theme.MaroonPrimary
import com.restaurantdemo.app.ui.theme.MutedText
import com.restaurantdemo.app.ui.theme.SuccessGreen

@Composable
fun ConfirmationScreen(
    orderId: String,
    onTrackOrder: () -> Unit,
    onBackToHome: () -> Unit
) {
    val orders by AppRepository.orders.collectAsState()
    val order = orders.find { it.id == orderId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(SuccessGreen.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Text("✅", style = MaterialTheme.typography.headlineLarge)
        }
        Spacer(Modifier.height(20.dp))
        Text("Order Placed!", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(6.dp))
        Text("Thank you, your order is being prepared.", color = MutedText, textAlign = androidx.compose.ui.text.style.TextAlign.Center)

        Spacer(Modifier.height(28.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.padding(20.dp)) {
                InfoRow("Order Number", order?.id ?: orderId)
                Spacer(Modifier.height(10.dp))
                InfoRow("Total Amount", formatPkr(order?.total ?: 0))
                Spacer(Modifier.height(10.dp))
                InfoRow("Estimated Delivery", "35–45 minutes")
            }
        }

        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onTrackOrder,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary)
        ) {
            Text("Track Order", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onBackToHome) {
            Text("Back to Home", color = MaroonPrimary)
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
        Text(label, color = MutedText)
        Text(value, fontWeight = FontWeight.Bold)
    }
}
