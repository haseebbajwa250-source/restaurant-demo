package com.restaurantdemo.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = MaroonPrimary,
    onPrimary = Color.White,
    primaryContainer = GoldAccentLight,
    onPrimaryContainer = MaroonDark,
    secondary = GoldAccent,
    onSecondary = Color.White,
    background = Cream,
    onBackground = CharcoalText,
    surface = CreamCard,
    onSurface = CharcoalText,
    surfaceVariant = Color(0xFFF6EBDD),
    onSurfaceVariant = MutedText,
    error = ErrorRed,
    outline = DividerColor,
)

@Composable
fun RestaurantDemoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = AppTypography,
        content = content
    )
}
