package com.restaurantdemo.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.restaurantdemo.app.data.AppRepository
import com.restaurantdemo.app.data.CartLine
import com.restaurantdemo.app.ui.components.*
import com.restaurantdemo.app.ui.theme.ErrorRed
import com.restaurantdemo.app.ui.theme.MaroonPrimary
import com.restaurantdemo.app.ui.theme.MutedText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    onBack: () -> Unit,
    onCheckout: () -> Unit
) {
    val cart by AppRepository.cart.collectAsState()
    val subtotal = cart.sumOf { it.lineTotal }
    val deliveryFee = if (subtotal > 0) AppRepository.DELIVERY_FEE else 0
    val total = subtotal + deliveryFee

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Cart") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        },
        bottomBar = {
            if (cart.isNotEmpty()) {
                Surface(shadowElevation = 10.dp) {
                    Column(Modifier.padding(20.dp)) {
                        SummaryRow("Subtotal", subtotal)
                        SummaryRow("Delivery Fee", deliveryFee)
                        Divider(Modifier.padding(vertical = 8.dp))
                        SummaryRow("Total", total, bold = true)
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = onCheckout,
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary)
                        ) {
                            Text("Proceed to Checkout", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    ) { padding ->
        if (cart.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                EmptyState("🛒", "Your cart is empty", "Browse the menu and add something delicious.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(cart, key = { it.food.id + it.selectedAddOns.joinToString { a -> a.id } }) { line ->
                    CartLineRow(line)
                }
            }
        }
    }
}

@Composable
private fun CartLineRow(line: CartLine) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        FoodImage(line.food.imageUrl, modifier = Modifier.size(66.dp).clip(RoundedCornerShape(12.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(line.food.name, style = MaterialTheme.typography.titleSmall)
            if (line.selectedAddOns.isNotEmpty()) {
                Text(
                    line.selectedAddOns.joinToString(", ") { it.name },
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedText
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(formatPkr(line.lineTotal), color = MaroonPrimary, fontWeight = FontWeight.Bold)
        }
        Column(horizontalAlignment = Alignment.End) {
            QuantityStepper(
                quantity = line.quantity,
                onIncrease = { AppRepository.updateQuantity(line.food, line.selectedAddOns, line.quantity + 1) },
                onDecrease = { AppRepository.updateQuantity(line.food, line.selectedAddOns, line.quantity - 1) }
            )
            TextButton(onClick = { AppRepository.removeFromCart(line.food, line.selectedAddOns) }) {
                Icon(Icons.Filled.Delete, contentDescription = "Remove", tint = ErrorRed, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Remove", color = ErrorRed, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, amount: Int, bold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, style = if (bold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium)
        Text(formatPkr(amount), fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, style = if (bold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium)
    }
}
