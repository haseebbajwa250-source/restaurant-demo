package com.restaurantdemo.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.restaurantdemo.app.data.AppRepository
import com.restaurantdemo.app.data.CustomerInfo
import com.restaurantdemo.app.data.PaymentMethod
import com.restaurantdemo.app.ui.components.formatPkr
import com.restaurantdemo.app.ui.theme.MaroonPrimary
import com.restaurantdemo.app.ui.theme.MutedText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(
    onBack: () -> Unit,
    onOrderPlaced: (String) -> Unit
) {
    val cart by AppRepository.cart.collectAsState()
    val lastCustomer by AppRepository.lastCustomer.collectAsState()
    val subtotal = cart.sumOf { it.lineTotal }
    val deliveryFee = if (subtotal > 0) AppRepository.DELIVERY_FEE else 0
    val total = subtotal + deliveryFee

    var name by remember { mutableStateOf(lastCustomer?.name.orEmpty()) }
    var phone by remember { mutableStateOf(lastCustomer?.phone.orEmpty()) }
    var address by remember { mutableStateOf(lastCustomer?.address.orEmpty()) }
    var notes by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf(PaymentMethod.COD) }
    var showError by remember { mutableStateOf(false) }

    val isValid = name.isNotBlank() && phone.isNotBlank() && address.isNotBlank() && cart.isNotEmpty()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Checkout") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        },
        bottomBar = {
            Surface(shadowElevation = 10.dp) {
                Column(Modifier.padding(20.dp)) {
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Total", style = MaterialTheme.typography.titleMedium)
                        Text(formatPkr(total), style = MaterialTheme.typography.titleMedium, color = MaroonPrimary, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            if (isValid) {
                                val order = AppRepository.placeOrder(
                                    CustomerInfo(name.trim(), phone.trim(), address.trim(), notes.trim()),
                                    payment
                                )
                                onOrderPlaced(order.id)
                            } else {
                                showError = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary)
                    ) {
                        Text("Place Order", fontWeight = FontWeight.Bold)
                    }
                    if (showError) {
                        Spacer(Modifier.height(8.dp))
                        Text("Please fill in all required fields.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Text("Delivery Details", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Customer Name *") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("Phone Number *") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = address, onValueChange = { address = it },
                label = { Text("Delivery Address *") },
                modifier = Modifier.fillMaxWidth(), minLines = 2
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = notes, onValueChange = { notes = it },
                label = { Text("Order Notes (optional)") },
                modifier = Modifier.fillMaxWidth(), minLines = 2
            )

            Spacer(Modifier.height(24.dp))
            Text("Payment Method", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            PaymentMethod.values().forEach { method ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    RadioButton(
                        selected = payment == method,
                        onClick = { payment = method },
                        colors = RadioButtonDefaults.colors(selectedColor = MaroonPrimary)
                    )
                    Text(method.label)
                }
            }
            if (payment == PaymentMethod.ONLINE) {
                Text(
                    "Demo mode: no real payment credentials are used. This is a placeholder for future payment gateway integration.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedText,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Spacer(Modifier.height(80.dp))
        }
    }
}
