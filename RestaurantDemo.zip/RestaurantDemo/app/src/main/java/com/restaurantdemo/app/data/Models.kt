package com.restaurantdemo.app.data

import java.text.SimpleDateFormat
import java.util.*

data class Category(
    val id: String,
    val name: String,
    val emoji: String
)

data class AddOn(
    val id: String,
    val name: String,
    val price: Int
)

data class FoodItem(
    val id: String,
    val name: String,
    val description: String,
    val price: Int, // PKR
    val imageUrl: String,
    val categoryId: String,
    val available: Boolean = true,
    val isFeatured: Boolean = false,
    val isPopular: Boolean = false,
    val addOns: List<AddOn> = emptyList()
)

data class CartLine(
    val food: FoodItem,
    val quantity: Int,
    val selectedAddOns: List<AddOn> = emptyList()
) {
    val unitPrice: Int get() = food.price + selectedAddOns.sumOf { it.price }
    val lineTotal: Int get() = unitPrice * quantity
}

enum class PaymentMethod(val label: String) {
    COD("Cash on Delivery"),
    ONLINE("Online Payment")
}

enum class OrderStatus(val label: String) {
    RECEIVED("Order Received"),
    PREPARING("Preparing"),
    READY("Ready"),
    OUT_FOR_DELIVERY("Out for Delivery"),
    DELIVERED("Delivered")
}

data class CustomerInfo(
    val name: String,
    val phone: String,
    val address: String,
    val notes: String = ""
)

data class Order(
    val id: String,
    val items: List<CartLine>,
    val customer: CustomerInfo,
    val paymentMethod: PaymentMethod,
    val subtotal: Int,
    val deliveryFee: Int,
    val total: Int,
    val status: OrderStatus = OrderStatus.RECEIVED,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun placedAt(): String =
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(timestamp))
}
