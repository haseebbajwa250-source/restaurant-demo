package com.restaurantdemo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.restaurantdemo.app.data.AppRepository
import com.restaurantdemo.app.data.FoodItem
import com.restaurantdemo.app.ui.components.*
import com.restaurantdemo.app.ui.theme.MaroonPrimary
import com.restaurantdemo.app.ui.theme.MutedText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(
    initialCategoryId: String?,
    initialQuery: String?,
    onBack: () -> Unit,
    onProductClick: (String) -> Unit
) {
    val categories by AppRepository.categories.collectAsState()
    val foods by AppRepository.foodItems.collectAsState()
    var selectedCategory by remember { mutableStateOf(initialCategoryId) }
    var query by remember { mutableStateOf(initialQuery.orEmpty()) }

    val filtered = foods.filter { food ->
        (selectedCategory == null || food.categoryId == selectedCategory) &&
            (query.isBlank() || food.name.contains(query, ignoreCase = true))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Menu") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search menu...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            )

            androidx.compose.foundation.lazy.LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { selectedCategory = null },
                        label = { Text("All") }
                    )
                }
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat.id,
                        onClick = { selectedCategory = cat.id },
                        label = { Text("${cat.emoji} ${cat.name}") }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))

            if (filtered.isEmpty()) {
                EmptyState("🔍", "No items found", "Try a different search or category.")
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                    items(filtered) { food ->
                        MenuRow(food, onClick = { onProductClick(food.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuRow(food: FoodItem, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = food.available) { onClick() }
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .alpha(if (food.available) 1f else 0.5f),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            FoodImage(food.imageUrl, modifier = Modifier.size(78.dp).clip(RoundedCornerShape(14.dp)))
            if (!food.available) {
                Box(modifier = Modifier.padding(4.dp)) { UnavailableBadge() }
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(food.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(food.description, style = MaterialTheme.typography.bodySmall, color = MutedText, maxLines = 2)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                PriceTag(food.price)
                if (food.available) {
                    FilledTonalButton(
                        onClick = { AppRepository.addToCart(food, 1) },
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = MaroonPrimary.copy(alpha = 0.12f)),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text("Add to Cart", color = MaroonPrimary, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
