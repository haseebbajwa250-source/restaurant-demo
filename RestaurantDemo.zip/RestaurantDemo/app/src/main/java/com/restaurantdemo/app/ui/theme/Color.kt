package com.restaurantdemo.app.ui.theme

import androidx.compose.ui.graphics.Color

// Premium restaurant palette: deep maroon/red + warm gold accent + cream
val MaroonPrimary = Color(0xFFB3251E)
val MaroonDark = Color(0xFF7A1712)
val GoldAccent = Color(0xFFE0A93B)
val GoldAccentLight = Color(0xFFF4D9A0)
val Cream = Color(0xFFFFF8F0)
val CreamCard = Color(0xFFFFFFFF)
val CharcoalText = Color(0xFF2B2118)
val MutedText = Color(0xFF8A7B6E)
val SuccessGreen = Color(0xFF3E8E5A)
val ErrorRed = Color(0xFFD3402C)
val DividerColor = Color(0xFFEFE3D3)
