package com.restaurantdemo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.restaurantdemo.app.data.*
import com.restaurantdemo.app.ui.components.EmptyState
import com.restaurantdemo.app.ui.components.FoodImage
import com.restaurantdemo.app.ui.components.formatPkr
import com.restaurantdemo.app.ui.theme.ErrorRed
import com.restaurantdemo.app.ui.theme.MaroonPrimary
import com.restaurantdemo.app.ui.theme.MutedText
import com.restaurantdemo.app.ui.theme.SuccessGreen

// ---------------- Admin Home ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHomeScreen(
    onBack: () -> Unit,
    onProducts: () -> Unit,
    onCategories: () -> Unit,
    onOrders: () -> Unit
) {
    val foods by AppRepository.foodItems.collectAsState()
    val orders by AppRepository.orders.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin Dashboard") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(20.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Menu Items", "${foods.size}", Modifier.weight(1f))
                StatCard("Total Orders", "${orders.size}", Modifier.weight(1f))
            }
            Spacer(Modifier.height(20.dp))
            AdminMenuTile("🍽️ Manage Food Items", "Add, edit, delete items · change prices & availability", onProducts)
            Spacer(Modifier.height(12.dp))
            AdminMenuTile("🏷️ Manage Categories", "Add or remove menu categories", onCategories)
            Spacer(Modifier.height(12.dp))
            AdminMenuTile("📦 View Orders", "See orders & update delivery status", onOrders)
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium, color = MaroonPrimary, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MutedText)
        }
    }
}

@Composable
private fun AdminMenuTile(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(18.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MutedText)
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MutedText)
        }
    }
}

// ---------------- Admin Product List ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminProductListScreen(
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
    onAddNew: () -> Unit
) {
    val foods by AppRepository.foodItems.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manage Food Items") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddNew, containerColor = MaroonPrimary) {
                Icon(Icons.Filled.Add, contentDescription = "Add item", tint = Color.White)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(foods, key = { it.id }) { food ->
                AdminProductRow(food, onEdit = { onEdit(food.id) })
            }
        }
    }
}

@Composable
private fun AdminProductRow(food: FoodItem, onEdit: () -> Unit) {
    var confirmDelete by remember { mutableStateOf(false) }

    Card(shape = RoundedCornerShape(14.dp)) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FoodImage(
                food.imageUrl,
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).alpha(if (food.available) 1f else 0.4f)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(food.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(formatPkr(food.price), color = MaroonPrimary, style = MaterialTheme.typography.bodySmall)
            }
            Switch(
                checked = food.available,
                onCheckedChange = { AppRepository.toggleAvailability(food.id) },
                colors = SwitchDefaults.colors(checkedThumbColor = SuccessGreen)
            )
            IconButton(onClick = onEdit) {
                Icon(Icons.Filled.Edit, contentDescription = "Edit", tint = MaroonPrimary)
            }
            IconButton(onClick = { confirmDelete = true }) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = ErrorRed)
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete item?") },
            text = { Text("Remove \"${food.name}\" from the menu permanently?") },
            confirmButton = {
                TextButton(onClick = {
                    AppRepository.deleteFoodItem(food.id)
                    confirmDelete = false
                }) { Text("Delete", color = ErrorRed) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancel") }
            }
        )
    }
}

// ---------------- Admin Product Edit / Create ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminProductEditScreen(
    foodId: String?, // null = new item
    onBack: () -> Unit
) {
    val foods by AppRepository.foodItems.collectAsState()
    val categories by AppRepository.categories.collectAsState()
    val existing = foods.find { it.id == foodId }

    var name by remember { mutableStateOf(existing?.name ?: "") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var price by remember { mutableStateOf(existing?.price?.toString() ?: "") }
    var imageUrl by remember { mutableStateOf(existing?.imageUrl ?: "") }
    var categoryId by remember { mutableStateOf(existing?.categoryId ?: categories.firstOrNull()?.id ?: "") }
    var available by remember { mutableStateOf(existing?.available ?: true) }
    var featured by remember { mutableStateOf(existing?.isFeatured ?: false) }
    var popular by remember { mutableStateOf(existing?.isPopular ?: false) }
    var categoryMenuExpanded by remember { mutableStateOf(false) }

    val isValid = name.isNotBlank() && price.toIntOrNull() != null && categoryId.isNotBlank()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) "Add Food Item" else "Edit Food Item") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            OutlinedTextField(name, { name = it }, label = { Text("Food Name *") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(description, { description = it }, label = { Text("Short Description") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                price, { price = it.filter { c -> c.isDigit() } },
                label = { Text("Price (PKR) *") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                imageUrl, { imageUrl = it },
                label = { Text("Image URL") },
                supportingText = { Text("Paste an image link (upload-to-cloud storage can be wired in later)") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )

            Spacer(Modifier.height(14.dp))
            Text("Category *", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            ExposedDropdownMenuBox(expanded = categoryMenuExpanded, onExpandedChange = { categoryMenuExpanded = it }) {
                OutlinedTextField(
                    value = categories.find { it.id == categoryId }?.name ?: "Select category",
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryMenuExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(expanded = categoryMenuExpanded, onDismissRequest = { categoryMenuExpanded = false }) {
                    categories.forEach { cat ->
                        DropdownMenuItem(text = { Text("${cat.emoji} ${cat.name}") }, onClick = {
                            categoryId = cat.id
                            categoryMenuExpanded = false
                        })
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            ToggleRow("Available for order", available) { available = it }
            ToggleRow("Show in Featured section", featured) { featured = it }
            ToggleRow("Show in Popular section", popular) { popular = it }

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    val item = FoodItem(
                        id = existing?.id ?: AppRepository.newFoodId(),
                        name = name.trim(),
                        description = description.trim(),
                        price = price.toIntOrNull() ?: 0,
                        imageUrl = imageUrl.ifBlank { "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&q=80" },
                        categoryId = categoryId,
                        available = available,
                        isFeatured = featured,
                        isPopular = popular,
                        addOns = existing?.addOns ?: emptyList()
                    )
                    AppRepository.upsertFoodItem(item)
                    onBack()
                },
                enabled = isValid,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary)
            ) {
                Text(if (existing == null) "Add Item to Menu" else "Save Changes", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedThumbColor = MaroonPrimary))
    }
}

// ---------------- Admin Categories ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminCategoriesScreen(onBack: () -> Unit) {
    val categories by AppRepository.categories.collectAsState()
    var newName by remember { mutableStateOf("") }
    var newEmoji by remember { mutableStateOf("🍴") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manage Categories") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    newEmoji, { if (it.length <= 2) newEmoji = it },
                    modifier = Modifier.width(70.dp), singleLine = true, label = { Text("Icon") }
                )
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(
                    newName, { newName = it },
                    modifier = Modifier.weight(1f), singleLine = true, label = { Text("New category name") }
                )
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = {
                    if (newName.isNotBlank()) {
                        AppRepository.addCategory(
                            Category(id = "cat_${System.currentTimeMillis()}", name = newName.trim(), emoji = newEmoji.ifBlank { "🍴" })
                        )
                        newName = ""
                    }
                }) {
                    Icon(Icons.Filled.AddCircle, contentDescription = "Add category", tint = MaroonPrimary)
                }
            }
            Spacer(Modifier.height(16.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories, key = { it.id }) { cat ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${cat.emoji}  ${cat.name}", style = MaterialTheme.typography.bodyLarge)
                        IconButton(onClick = { AppRepository.deleteCategory(cat.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = ErrorRed)
                        }
                    }
                    Divider()
                }
            }
        }
    }
}

// ---------------- Admin Orders ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminOrdersScreen(onBack: () -> Unit) {
    val orders by AppRepository.orders.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Orders") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        if (orders.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize()) {
                EmptyState("📦", "No orders yet", "Orders placed by customers will show up here.")
            }
            return@Scaffold
        }
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(orders.reversed(), key = { it.id }) { order ->
                AdminOrderCard(order)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminOrderCard(order: Order) {
    var expanded by remember { mutableStateOf(false) }
    var statusMenuOpen by remember { mutableStateOf(false) }

    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Order #${order.id}", fontWeight = FontWeight.Bold)
                    Text(order.customer.name.ifBlank { "Guest" } + " · " + order.customer.phone, style = MaterialTheme.typography.bodySmall, color = MutedText)
                    Text(order.placedAt(), style = MaterialTheme.typography.bodySmall, color = MutedText)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(formatPkr(order.total), fontWeight = FontWeight.Bold, color = MaroonPrimary)
                    Text(order.paymentMethod.label, style = MaterialTheme.typography.bodySmall, color = MutedText)
                }
            }

            Spacer(Modifier.height(10.dp))
            Box {
                AssistChip(
                    onClick = { statusMenuOpen = true },
                    label = { Text(order.status.label) }
                )
                DropdownMenu(expanded = statusMenuOpen, onDismissRequest = { statusMenuOpen = false }) {
                    OrderStatus.values().forEach { status ->
                        DropdownMenuItem(text = { Text(status.label) }, onClick = {
                            AppRepository.updateOrderStatus(order.id, status)
                            statusMenuOpen = false
                        })
                    }
                }
            }

            if (expanded) {
                Spacer(Modifier.height(10.dp))
                Divider()
                Spacer(Modifier.height(10.dp))
                Text("Delivery Address", style = MaterialTheme.typography.labelMedium, color = MutedText)
                Text(order.customer.address, style = MaterialTheme.typography.bodyMedium)
                if (order.customer.notes.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text("Notes", style = MaterialTheme.typography.labelMedium, color = MutedText)
                    Text(order.customer.notes, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(10.dp))
                Text("Items", style = MaterialTheme.typography.labelMedium, color = MutedText)
                order.items.forEach { line ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${line.quantity}× ${line.food.name}", style = MaterialTheme.typography.bodySmall)
                        Text(formatPkr(line.lineTotal), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
