package com.restaurantdemo.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.restaurantdemo.app.ui.theme.GoldAccent
import com.restaurantdemo.app.ui.theme.MaroonDark
import com.restaurantdemo.app.ui.theme.MaroonPrimary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val scaleAnim = remember { Animatable(0.7f) }
    val alphaAnim = remember { Animatable(0f) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        scaleAnim.animateTo(1f, animationSpec = tween(600, easing = FastOutSlowInEasing))
    }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        alphaAnim.animateTo(1f, animationSpec = tween(800))
    }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        delay(1800)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(MaroonDark, MaroonPrimary))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .graphicsLayer(scaleX = scaleAnim.value, scaleY = scaleAnim.value)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Text("🍽️", style = MaterialTheme.typography.headlineLarge)
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "Restaurant Demo",
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.graphicsLayer(alpha = alphaAnim.value)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Delicious food, delivered to you",
                color = GoldAccent,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.graphicsLayer(alpha = alphaAnim.value)
            )
        }
    }
}
