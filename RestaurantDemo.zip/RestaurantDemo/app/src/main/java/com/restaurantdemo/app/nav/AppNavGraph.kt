package com.restaurantdemo.app.nav

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.restaurantdemo.app.data.AppRepository
import com.restaurantdemo.app.ui.screens.*

private enum class BottomTab(val baseRoute: String, val label: String, val icon: ImageVector) {
    HOME(Routes.HOME, "Home", Icons.Filled.Home),
    MENU("menu", "Menu", Icons.Filled.RestaurantMenu),
    CART(Routes.CART, "Cart", Icons.Filled.ShoppingCart),
    PROFILE(Routes.PROFILE, "Profile", Icons.Filled.Person),
}

@Composable
fun AppNavGraph() {
    val navController = rememberNavController()
    val cart by AppRepository.cart.collectAsState()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val currentBaseRoute = currentRoute?.substringBefore("?")

    val showBottomBar = currentBaseRoute in listOf("home", "menu", "cart", "profile")

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    BottomTab.values().forEach { tab ->
                        val selected = currentBaseRoute == tab.baseRoute
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                val target = if (tab == BottomTab.MENU) Routes.menu() else tab.baseRoute
                                navController.navigate(target) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                if (tab == BottomTab.CART && cart.isNotEmpty()) {
                                    BadgedBox(badge = { Badge { Text("${cart.sumOf { it.quantity }}") } }) {
                                        Icon(tab.icon, contentDescription = tab.label)
                                    }
                                } else {
                                    Icon(tab.icon, contentDescription = tab.label)
                                }
                            },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.SPLASH,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(onFinished = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                })
            }
            composable(Routes.HOME) {
                HomeScreen(
                    onCategoryClick = { catId -> navController.navigate(Routes.menu(catId)) },
                    onProductClick = { id -> navController.navigate(Routes.productDetail(id)) },
                    onSearchSubmit = { navController.navigate(Routes.menu()) },
                    onCartClick = { navController.navigate(Routes.CART) }
                )
            }
            composable(
                Routes.MENU,
                arguments = listOf(navArgument("categoryId") { defaultValue = "" })
            ) { entry ->
                val catId = entry.arguments?.getString("categoryId")?.ifBlank { null }
                MenuScreen(
                    initialCategoryId = catId,
                    initialQuery = null,
                    onBack = { navController.popBackStack() },
                    onProductClick = { id -> navController.navigate(Routes.productDetail(id)) }
                )
            }
            composable(
                Routes.PRODUCT_DETAIL,
                arguments = listOf(navArgument("foodId") { })
            ) { entry ->
                val foodId = entry.arguments?.getString("foodId") ?: ""
                ProductDetailScreen(
                    foodId = foodId,
                    onBack = { navController.popBackStack() },
                    onAddedToCart = { navController.navigate(Routes.CART) }
                )
            }
            composable(Routes.CART) {
                CartScreen(
                    onBack = { navController.popBackStack() },
                    onCheckout = { navController.navigate(Routes.CHECKOUT) }
                )
            }
            composable(Routes.CHECKOUT) {
                CheckoutScreen(
                    onBack = { navController.popBackStack() },
                    onOrderPlaced = { orderId ->
                        navController.navigate(Routes.confirmation(orderId)) {
                            popUpTo(Routes.HOME)
                        }
                    }
                )
            }
            composable(
                Routes.CONFIRMATION,
                arguments = listOf(navArgument("orderId") { })
            ) { entry ->
                val orderId = entry.arguments?.getString("orderId") ?: ""
                ConfirmationScreen(
                    orderId = orderId,
                    onTrackOrder = { navController.navigate(Routes.tracking(orderId)) },
                    onBackToHome = {
                        navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } }
                    }
                )
            }
            composable(
                Routes.TRACKING,
                arguments = listOf(navArgument("orderId") { })
            ) { entry ->
                val orderId = entry.arguments?.getString("orderId") ?: ""
                TrackingScreen(orderId = orderId, onBack = { navController.popBackStack() })
            }
            composable(Routes.PROFILE) {
                ProfileScreen(
                    onOrderClick = { orderId -> navController.navigate(Routes.tracking(orderId)) },
                    onOpenAdmin = { navController.navigate(Routes.ADMIN_HOME) }
                )
            }

            // ---------------- Admin ----------------
            composable(Routes.ADMIN_HOME) {
                AdminHomeScreen(
                    onBack = { navController.popBackStack() },
                    onProducts = { navController.navigate(Routes.ADMIN_PRODUCTS) },
                    onCategories = { navController.navigate(Routes.ADMIN_CATEGORIES) },
                    onOrders = { navController.navigate(Routes.ADMIN_ORDERS) }
                )
            }
            composable(Routes.ADMIN_PRODUCTS) {
                AdminProductListScreen(
                    onBack = { navController.popBackStack() },
                    onEdit = { id -> navController.navigate(Routes.adminProductEdit(id)) },
                    onAddNew = { navController.navigate(Routes.ADMIN_PRODUCT_NEW) }
                )
            }
            composable(Routes.ADMIN_PRODUCT_NEW) {
                AdminProductEditScreen(foodId = null, onBack = { navController.popBackStack() })
            }
            composable(
                Routes.ADMIN_PRODUCT_EDIT,
                arguments = listOf(navArgument("foodId") { })
            ) { entry ->
                val foodId = entry.arguments?.getString("foodId")
                AdminProductEditScreen(foodId = foodId, onBack = { navController.popBackStack() })
            }
            composable(Routes.ADMIN_CATEGORIES) {
                AdminCategoriesScreen(onBack = { navController.popBackStack() })
            }
            composable(Routes.ADMIN_ORDERS) {
                AdminOrdersScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
