package com.restaurantdemo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.restaurantdemo.app.data.AddOn
import com.restaurantdemo.app.data.AppRepository
import com.restaurantdemo.app.ui.components.*
import com.restaurantdemo.app.ui.theme.MaroonPrimary
import com.restaurantdemo.app.ui.theme.MutedText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(
    foodId: String,
    onBack: () -> Unit,
    onAddedToCart: () -> Unit
) {
    val foods by AppRepository.foodItems.collectAsState()
    val food = foods.find { it.id == foodId }

    if (food == null) {
        EmptyState("😕", "Item not found", "This item may have been removed.")
        return
    }

    var quantity by remember { mutableStateOf(1) }
    val selectedAddOns = remember { mutableStateListOf<AddOn>() }

    val addOnsTotal = selectedAddOns.sumOf { it.price }
    val totalPrice = (food.price + addOnsTotal) * quantity

    Scaffold(
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            AppRepository.addToCart(food, quantity, selectedAddOns.toList())
                            onAddedToCart()
                        },
                        enabled = food.available,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary)
                    ) {
                        Text(
                            if (food.available) "Add to Cart · ${formatPkr(totalPrice)}" else "Currently Unavailable",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScrollCompat()
        ) {
            Box {
                FoodImage(food.imageUrl, modifier = Modifier.fillMaxWidth().height(280.dp))
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .padding(16.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.9f))
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = MaroonPrimary)
                }
            }

            Column(Modifier.padding(20.dp)) {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(food.name, style = MaterialTheme.typography.headlineMedium)
                }
                Spacer(Modifier.height(8.dp))
                PriceTag(food.price)
                Spacer(Modifier.height(12.dp))
                Text(food.description, style = MaterialTheme.typography.bodyLarge, color = MutedText)

                Spacer(Modifier.height(24.dp))
                Text("Quantity", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                QuantityStepper(
                    quantity = quantity,
                    onIncrease = { quantity++ },
                    onDecrease = { if (quantity > 1) quantity-- }
                )

                if (food.addOns.isNotEmpty()) {
                    Spacer(Modifier.height(24.dp))
                    Text("Optional Add-ons", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    food.addOns.forEach { addOn ->
                        val checked = selectedAddOns.contains(addOn)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (checked) selectedAddOns.remove(addOn) else selectedAddOns.add(addOn)
                                }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = {
                                        if (it) selectedAddOns.add(addOn) else selectedAddOns.remove(addOn)
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = MaroonPrimary)
                                )
                                Text(addOn.name)
                            }
                            Text("+ ${formatPkr(addOn.price)}", color = MutedText)
                        }
                    }
                }
                Spacer(Modifier.height(80.dp))
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun Modifier.verticalScrollCompat(): Modifier {
    val scrollState = androidx.compose.foundation.rememberScrollState()
    return this.then(androidx.compose.foundation.verticalScroll(scrollState))
}
