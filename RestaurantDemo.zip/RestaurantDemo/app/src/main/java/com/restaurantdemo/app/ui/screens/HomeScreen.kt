package com.restaurantdemo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.restaurantdemo.app.data.AppRepository
import com.restaurantdemo.app.data.Category
import com.restaurantdemo.app.data.FoodItem
import com.restaurantdemo.app.ui.components.*
import com.restaurantdemo.app.ui.theme.GoldAccentLight
import com.restaurantdemo.app.ui.theme.MaroonPrimary
import com.restaurantdemo.app.ui.theme.MutedText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onCategoryClick: (String) -> Unit,
    onProductClick: (String) -> Unit,
    onSearchSubmit: (String) -> Unit,
    onCartClick: () -> Unit
) {
    val categories by AppRepository.categories.collectAsState()
    val foods by AppRepository.foodItems.collectAsState()
    val cart by AppRepository.cart.collectAsState()
    var query by remember { mutableStateOf("") }

    val featured = foods.filter { it.isFeatured && it.available }
    val popular = foods.filter { it.isPopular && it.available }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaroonPrimary)
                    .padding(top = 20.dp, bottom = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("🍽️ Restaurant Demo", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                        Text("Delicious food, delivered to you", color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall)
                    }
                    BadgedBox(badge = {
                        if (cart.isNotEmpty()) {
                            Badge { Text("${cart.sumOf { it.quantity }}") }
                        }
                    }) {
                        IconButton(onClick = onCartClick) {
                            Icon(androidx.compose.material.icons.Icons.Filled.ShoppingCart, contentDescription = "Cart", tint = Color.White)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search food...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { onSearchSubmit(query) }),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clickable { onSearchSubmit(query) }
                )
            }
        }
    ) { padding ->
        androidx.compose.foundation.lazy.LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            item {
                Spacer(Modifier.height(12.dp))
                SectionHeader("Categories")
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(categories) { cat ->
                        CategoryChip(cat) { onCategoryClick(cat.id) }
                    }
                }
                Spacer(Modifier.height(20.dp))
            }

            if (featured.isNotEmpty()) {
                item {
                    SectionHeader("Featured")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(featured) { food ->
                            FeaturedCard(food) { onProductClick(food.id) }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }

            item {
                SectionHeader("Popular Items")
            }
            items(popular) { food ->
                PopularRow(food) { onProductClick(food.id) }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun CategoryChip(category: Category, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(GoldAccentLight),
            contentAlignment = Alignment.Center
        ) {
            Text(category.emoji, style = MaterialTheme.typography.headlineMedium)
        }
        Spacer(Modifier.height(6.dp))
        Text(category.name, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun FeaturedCard(food: FoodItem, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(200.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Box {
            FoodImage(food.imageUrl, modifier = Modifier.fillMaxWidth().height(120.dp))
            if (food.isPopular) {
                Box(modifier = Modifier.padding(8.dp)) { PopularBadge() }
            }
        }
        Column(Modifier.padding(12.dp)) {
            Text(food.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            PriceTag(food.price)
        }
    }
}

@Composable
private fun PopularRow(food: FoodItem, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FoodImage(
            food.imageUrl,
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(food.name, style = MaterialTheme.typography.titleSmall)
            Text(food.description, style = MaterialTheme.typography.bodySmall, color = MutedText, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            PriceTag(food.price)
        }
    }
}
