# Restaurant Demo — Android App

A modern, premium-styled Android restaurant ordering app built with **Kotlin + Jetpack Compose (Material 3)**.

## How to open & run
1. Install **Android Studio** (Koala/2024.1 or newer recommended).
2. `File > Open` → select the `RestaurantDemo` folder (this project root).
3. Let Gradle sync (Android Studio will offer to create the Gradle wrapper if it's missing — accept it, or run `gradle wrapper` once if you have Gradle installed locally).
4. Run on an emulator or physical device (minSdk 24 / Android 7.0+).
5. An internet connection on the device/emulator is needed to load the demo food photos (they're pulled from Unsplash URLs) — everything else works fully offline.

## What's included
- **All 9 customer screens**: Splash, Home, Menu, Product Details, Cart, Checkout, Order Confirmation, Order Tracking, Profile.
- **Full Admin Panel** (open it from the Profile screen → "Restaurant Admin Panel"): add/edit/delete food items, change prices, set image URLs, manage categories, view orders with full details, change order status, mark items available/unavailable.
- **Realistic Pakistani menu** with PKR pricing (Zinger Burger Rs 450, Chicken Pizza Rs 850, Chicken Biryani Rs 350, Loaded Fries Rs 400, Chicken Roll Rs 300, Soft Drink Rs 120, Chocolate Brownie Rs 250, plus more).
- Functional cart with quantity controls, add-ons, subtotal/delivery fee/total math.
- Order placement, order number generation, and a live-updating order tracking timeline.
- Bottom navigation (Home / Menu / Cart / Profile) with a live cart item-count badge.

## Architecture (ready for Firebase / Room later)
Everything currently flows through a single reactive in-memory store: `data/AppRepository.kt`.
It exposes `StateFlow`s for categories, food items, cart, and orders — so **any admin change (price,
availability, new item, order status) instantly reflects on the customer side**, because both sides
read from the same flows.

To wire up a real backend later, you only need to change the *inside* of `AppRepository`'s functions
(e.g. read/write Firestore or a Room database instead of mutating in-memory lists) — the public
function signatures (`upsertFoodItem`, `placeOrder`, `updateOrderStatus`, etc.) are designed to stay
the same, so the UI screens would not need to change.

Suggested next steps for production:
- Swap `AppRepository`'s in-memory lists for **Firebase Firestore** (menu/orders) + **Firebase Storage** (food images) + **Firebase Auth** (customer accounts).
- Replace the demo "Online Payment" option with a real gateway (e.g. JazzCash, Easypaisa, or Stripe) — no real payment credentials are used anywhere in this demo.
- Add push notifications (FCM) for order status changes.
- Add authentication/role-checks so only restaurant staff can reach the Admin Panel.

## Project structure
```
app/src/main/java/com/restaurantdemo/app/
  data/         Models, demo data, AppRepository (single source of truth)
  ui/theme/     Colors, typography, Material3 theme
  ui/components/  Reusable UI pieces (price tag, quantity stepper, badges, etc.)
  ui/screens/   One file per screen (Home, Menu, Cart, Checkout, Admin*, etc.)
  nav/          Navigation routes + NavHost graph
  MainActivity.kt
```
